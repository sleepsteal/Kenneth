﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Compute_Tax : Form
    {
        dbConn con = new dbConn();
        public frm_Compute_Tax()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Treasury tres = new frm_Treasury();
            tres.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string lot = txt_lot.Text.Trim().ToString();
            string owner = txt_owner.Text.Trim().ToString();
            string yr = txt_year.Text.Trim().ToString();
            string quarter = cmb_quarter.Text.Trim().ToString();
            string market = txt_market.Text.Trim().ToString();
            string assess = txt_assessed.Text.Trim().ToString();
            string last_yr = txt_lastYear.Text.Trim().ToString();

            string sqlSelect = "SELECT * FROM `tbl_land_info` WHERE `Lot_Number` = '"+lot+"'";
            con.getID(sqlSelect, lbl_id, txt_market, txt_assessed);

            string sqlSelect1 = "SELECT * FROM  `tbl_land_owner` WHERE `ID` = '"+lbl_id.Text+"'";
            con.getName(sqlSelect1, txt_owner);
        }

        private void btn_compute_Click(object sender, EventArgs e)
        {
            
            string quarter = cmb_quarter.Text.Trim().ToString();

            string sqlSelect1 = "SELECT * FROM `tbl_tax`";
            con.getTaxes(sqlSelect1, lbl_tax, lbl_pen);

            double monthly_pen = Convert.ToDouble(lbl_pen.Text.Trim().ToString());
            double tax_percent = Convert.ToDouble(lbl_tax.Text.Trim().ToString());
            

            double year = Convert.ToDouble(txt_year.Text.Trim().ToString());
            double last_yr = Convert.ToDouble(txt_lastYear.Text.Trim().ToString());

            double penalty = 0;
            penalty = Convert.ToDouble(lbl_Penalty.Text.Trim().ToString());
            penalty = (year - last_yr);
            if (penalty <= 10)
            {
                penalty = (penalty * 12) * (monthly_pen / 100);
                lbl_Penalty.Text = "₱ " + penalty.ToString("N2");
            }
            else if (penalty == 0)
            {
                penalty = 0;
                lbl_Penalty.Text = "₱ " + penalty.ToString("N2");
            }
            else
            {
                lbl_Penalty.Text = "Amnesty";
            }

            double m_value = 0;
            m_value = Convert.ToDouble(txt_market.Text.Trim().ToString());
            double a_value = 0;
            a_value = Convert.ToDouble(txt_assessed.Text.Trim().ToString());

            double tax_due = 0;
            tax_due = Convert.ToDouble(lbl_TaxDue.Text.Trim().ToString());
            tax_due = (a_value * (tax_percent / 100));
            lbl_TaxDue.Text = "₱ " + tax_due.ToString("N2");

            double discount = 0;
            discount = Convert.ToDouble(lbl_DisTotals.Text.Trim().ToString());

            if (quarter == "First Quarter")
            {
                discount = (tax_due * 0.1);
                lbl_DisTotals.Text = "₱ " + discount.ToString("N2");
            }
            else if (quarter == "Second Quarter" || quarter == "Third Quarter" || quarter == "Fourth Quater")
            {
                discount = (tax_due * 0.2);
                lbl_DisTotals.Text = "₱ " + discount.ToString("N2");
            }
            else
            {
                MessageBox.Show("Please indicate the quarter.");
            }

            double total = 0;
            total = Convert.ToDouble(lbl_Total.Text.Trim().ToString());
            total = ((tax_due + penalty) + (tax_due + penalty) - discount);
            lbl_Total.Text = "₱ " + total.ToString("N2");           
           
        }

        private void frm_Compute_Tax_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT * FROM `tbl_land_info` LEFT JOIN `tbl_land_owner` ON `tbl_land_owner`.`ID` = `tbl_land_info`.`Owner_FK`";
            con.getData(sqlSelect, lvi_records);

            
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            DialogResult ans = MessageBox.Show("Are you sure?", "Proceed to next client.", MessageBoxButtons.YesNo);
            if (ans == DialogResult.Yes)
            {
                string lot_num = txt_lot.Text.Trim().ToString();
                string lot_owner = txt_owner.Text.Trim().ToString();
                string year = txt_year.Text.Trim().ToString();
                string market = txt_market.Text.Trim().ToString();
                string assess = txt_assessed.Text.Trim().ToString();
                string total = lbl_Total.Text.Trim().ToString();

                string sqlInsert = "INSERT INTO `tbl_t_records` (`Lot_Number`, `Lot_Owner`, `Year_Paid`, `Market_Value`, `Assessed_Value`, `Total_Due`) VALUES  ('" + lot_num + "', '" + lot_owner + "', '" + year + "', '" + market + "', '" + assess + "', '"+total+"')";
                con.insert(sqlInsert);
                MessageBox.Show("Next Client");

                txt_assessed.Clear();
                txt_lastYear.Clear();
                txt_lot.Clear();
                txt_market.Clear();
                txt_year.Clear();
                cmb_quarter.Text = string.Empty;
                txt_owner.Clear();
                lbl_DisTotals.Text = "0";
                lbl_TaxDue.Text = "0";
                lbl_Penalty.Text = "0";
                lbl_Total.Text = "0";
                lbl_id.Text = "";
            }
            
        }
    }
}
