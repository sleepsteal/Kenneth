﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Assessor : Form
    {
        public frm_Assessor()
        {
            InitializeComponent();
        }

        private void btn_records_Click(object sender, EventArgs e)
        {
            frm_landrecord land = new frm_landrecord();
            land.Show();
            this.Hide();
               
        }

        private void btn_owners_Click(object sender, EventArgs e)
        {
            frm_Land_Owners own = new frm_Land_Owners();
            own.Show();
            this.Hide();
        }

        private void btn_map_Click(object sender, EventArgs e)
        {
            frm_Map map = new frm_Map();
            map.Show();
            this.Hide();
        }

        private void btn_assessment_Click(object sender, EventArgs e)
        {
            frm_Assessment_Request req = new frm_Assessment_Request();
            req.Show();
            this.Hide();
        }

        private void btn_survey_Click(object sender, EventArgs e)
        {
            frm_admin_surveyor surv = new frm_admin_surveyor();
            surv.Show();
            this.Hide();
        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Logout?", "Logout?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Form1 login = new Form1();
                login.Show();
                this.Hide();
            }
            else
            {
                //do nothing
            }
        }
    }
}
