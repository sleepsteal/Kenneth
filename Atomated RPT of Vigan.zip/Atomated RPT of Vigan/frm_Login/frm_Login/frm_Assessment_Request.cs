﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Assessment_Request : Form
    {
        dbConn con = new dbConn();
        public frm_Assessment_Request()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Assessor asse = new frm_Assessor();
            asse.Show();
            this.Hide();
        }

        private void frm_Assessment_Request_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT * FROM `tbl_assessment_request`";
            con.getRequest(sqlSelect,lvi_request);
        }
    }
}
