﻿namespace frm_Login
{
    partial class frm_users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_users));
            this.btn_logOut = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_requestAssessment = new System.Windows.Forms.Button();
            this.btn_requestSurveyor = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_viewRecords = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_logOut
            // 
            this.btn_logOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_logOut.Location = new System.Drawing.Point(21, 658);
            this.btn_logOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(149, 59);
            this.btn_logOut.TabIndex = 8;
            this.btn_logOut.Text = "Logout";
            this.btn_logOut.UseVisualStyleBackColor = false;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btn_logOut);
            this.panel1.Controls.Add(this.btn_requestAssessment);
            this.panel1.Controls.Add(this.btn_requestSurveyor);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btn_viewRecords);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 750);
            this.panel1.TabIndex = 3;
            // 
            // btn_requestAssessment
            // 
            this.btn_requestAssessment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_requestAssessment.Location = new System.Drawing.Point(21, 331);
            this.btn_requestAssessment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_requestAssessment.Name = "btn_requestAssessment";
            this.btn_requestAssessment.Size = new System.Drawing.Size(149, 52);
            this.btn_requestAssessment.TabIndex = 6;
            this.btn_requestAssessment.Text = "Request Assessment";
            this.btn_requestAssessment.UseVisualStyleBackColor = false;
            this.btn_requestAssessment.Click += new System.EventHandler(this.btn_requestAssessment_Click);
            // 
            // btn_requestSurveyor
            // 
            this.btn_requestSurveyor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_requestSurveyor.Location = new System.Drawing.Point(21, 267);
            this.btn_requestSurveyor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_requestSurveyor.Name = "btn_requestSurveyor";
            this.btn_requestSurveyor.Size = new System.Drawing.Size(149, 58);
            this.btn_requestSurveyor.TabIndex = 5;
            this.btn_requestSurveyor.Text = "Request Surveryor";
            this.btn_requestSurveyor.UseVisualStyleBackColor = false;
            this.btn_requestSurveyor.Click += new System.EventHandler(this.btn_requestSurveyor_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Location = new System.Drawing.Point(21, 18);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(161, 160);
            this.panel3.TabIndex = 4;
            // 
            // btn_viewRecords
            // 
            this.btn_viewRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_viewRecords.Location = new System.Drawing.Point(21, 210);
            this.btn_viewRecords.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_viewRecords.Name = "btn_viewRecords";
            this.btn_viewRecords.Size = new System.Drawing.Size(149, 50);
            this.btn_viewRecords.TabIndex = 0;
            this.btn_viewRecords.Text = "Land Records (Public)";
            this.btn_viewRecords.UseVisualStyleBackColor = false;
            this.btn_viewRecords.Click += new System.EventHandler(this.btn_viewRecords_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(361, 263);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 44);
            this.label1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(795, 66);
            this.panel2.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(335, 210);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(497, 447);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // frm_users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(995, 750);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frm_users";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Users";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_requestAssessment;
        private System.Windows.Forms.Button btn_requestSurveyor;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_viewRecords;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}