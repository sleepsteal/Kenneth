﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace frm_Login
{
    class dbConn
    {
        String str = @"server = localhost; database = db_prototype; userid = root; password =;";
        MySqlConnection con = null;

        public void Connect()
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open();
            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }
        public string encryption(string password)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(password));
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }


        public void insert(string sqlInsert)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open();
                MySqlCommand cmd = new MySqlCommand(sqlInsert, con);
                cmd.ExecuteNonQuery();
            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void Select(string sqlSelect, Label lbl_user, Label lbl_pass)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_user.Text = rdr.GetValue(0).ToString();
                lbl_pass.Text = rdr.GetValue(1).ToString();
            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void Select_ID(string sqlSelect, Label lbl_ID)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                Console.WriteLine(sqlSelect);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_ID.Text = rdr.GetValue(0).ToString();             

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void Select_1(string sqlSelect_1, Label lbl_user, Label lbl_pass, Label lbl_user_type)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect_1;
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_user.Text = rdr.GetValue(0).ToString();
                lbl_pass.Text = rdr.GetValue(1).ToString();
                lbl_user_type.Text = rdr.GetValue(2).ToString();

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void search(string sqlSelect, Label lbl_OwnerID)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                Console.WriteLine(sqlSelect);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_OwnerID.Text = rdr.GetValue(0).ToString();               

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void getLot(string sqlSelect, ListView lvi_Lot)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = rdr.GetValue(2).ToString();
                    lvi.SubItems.Add(rdr.GetValue(6).ToString());
                    lvi.SubItems.Add(rdr.GetValue(3).ToString());
                    lvi.SubItems.Add(rdr.GetValue(4).ToString());                    
                    lvi_Lot.Items.Add(lvi);
                }


            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void delete(string sqlDelete)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd = new MySqlCommand(sqlDelete, con);
                cmd.ExecuteNonQuery();
            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void view(string sqlSelect, ListView lvi_owners)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = (rdr["Full_Name"].ToString());
                    lvi.SubItems.Add(rdr["Barangay"].ToString() + " " + rdr["City/Mun"].ToString() + " " + rdr["Province"].ToString());
                    lvi.SubItems.Add(rdr["Lot_Number"].ToString());                    
                    lvi_owners.Items.Add(lvi);
                }


            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void getTax(string sqlSelect, Label lbl_tax, Label lbl_pen)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                Console.WriteLine(sqlSelect);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_tax.Text = rdr.GetValue(0).ToString();
                lbl_pen.Text = rdr.GetValue(1).ToString();

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void getData(string sqlSelect, ListView lvi_records)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = (rdr["Lot_Number"].ToString());
                    lvi.SubItems.Add(rdr["Full_Name"].ToString());
                    lvi.SubItems.Add(rdr["Classification"].ToString());
                    lvi.SubItems.Add(rdr["Land_Area"].ToString());
                    lvi.SubItems.Add(rdr["Market_Value"].ToString());
                    lvi.SubItems.Add(rdr["Assessed_Value"].ToString());
                    lvi_records.Items.Add(lvi);
                }


            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void getID(string sqlSelect, Label lbl_id, TextBox txt_market, TextBox txt_assessed)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                Console.WriteLine(sqlSelect);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_id.Text = rdr.GetValue(1).ToString();
                txt_market.Text = rdr.GetValue(7).ToString();
                txt_assessed.Text = rdr.GetValue(8).ToString();

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void getName(string sqlSelect1, TextBox txt_owner)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect1;
                Console.WriteLine(sqlSelect1);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                
                txt_owner.Text = rdr.GetValue(1).ToString();
                

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void getTaxes(string sqlSelect1, Label lbl_tax, Label lbl_pen)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect1;
                Console.WriteLine(sqlSelect1);
                MySqlDataReader rdr = cmd.ExecuteReader();
                rdr.Read();
                lbl_tax.Text = rdr.GetValue(1).ToString();
                lbl_pen.Text = rdr.GetValue(2).ToString();

            }
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Clone();
                }
            }
        }

        public void getRecord(string sqlSelect, ListView lvi_records)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = rdr.GetValue(1).ToString();
                    lvi.SubItems.Add(rdr.GetValue(2).ToString());
                    lvi.SubItems.Add(rdr.GetValue(3).ToString());
                    lvi.SubItems.Add(rdr.GetValue(4).ToString());
                    lvi.SubItems.Add(rdr.GetValue(5).ToString());
                    lvi.SubItems.Add(rdr.GetValue(6).ToString());
                    lvi_records.Items.Add(lvi);
                }


            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }

        public void getRequest(string sqlSelect, ListView lvi_request)
        {
            try
            {
                con = new MySqlConnection(str);
                con.Open(); //open the connection
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandText = sqlSelect;
                MySqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = rdr.GetValue(1).ToString();
                    lvi.SubItems.Add(rdr.GetValue(2).ToString() + " " + rdr.GetValue(3).ToString() + " " + rdr.GetValue(4).ToString());
                    lvi.SubItems.Add(rdr.GetValue(6).ToString());
                    lvi.SubItems.Add(rdr.GetValue(7).ToString());
                    lvi_request.Items.Add(lvi);
                }


            } //captures and displays any MySql errors that will occur
            catch (MySqlException err)
            {
                Console.WriteLine("Error: " + err.ToString());
            }
            finally
            {
                if (con != null)
                {
                    con.Close(); //safely close conn
                }
            }
        }
    }  

}
