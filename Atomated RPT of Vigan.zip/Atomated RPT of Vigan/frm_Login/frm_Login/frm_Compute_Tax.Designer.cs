﻿namespace frm_Login
{
    partial class frm_Compute_Tax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Compute_Tax));
            this.lvi_records = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txt_lot = new System.Windows.Forms.TextBox();
            this.txt_owner = new System.Windows.Forms.TextBox();
            this.txt_year = new System.Windows.Forms.TextBox();
            this.txt_market = new System.Windows.Forms.TextBox();
            this.txt_assessed = new System.Windows.Forms.TextBox();
            this.txt_lastYear = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_Penalty = new System.Windows.Forms.Label();
            this.lbl_TaxDue = new System.Windows.Forms.Label();
            this.lbl_DisTotals = new System.Windows.Forms.Label();
            this.lblTotal1 = new System.Windows.Forms.Label();
            this.lblTotalDisc = new System.Windows.Forms.Label();
            this.lblPenalty1 = new System.Windows.Forms.Label();
            this.lblTaxDue1 = new System.Windows.Forms.Label();
            this.cmb_quarter = new System.Windows.Forms.ComboBox();
            this.btn_compute = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.lbl_id = new System.Windows.Forms.Label();
            this.lbl_tax = new System.Windows.Forms.Label();
            this.lbl_pen = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvi_records
            // 
            this.lvi_records.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.lvi_records.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lvi_records.Location = new System.Drawing.Point(17, 322);
            this.lvi_records.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lvi_records.Name = "lvi_records";
            this.lvi_records.Size = new System.Drawing.Size(968, 355);
            this.lvi_records.TabIndex = 0;
            this.lvi_records.UseCompatibleStateImageBehavior = false;
            this.lvi_records.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Lot Number";
            this.columnHeader1.Width = 132;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Owner";
            this.columnHeader2.Width = 223;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Classification";
            this.columnHeader3.Width = 142;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Land Area";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Market Value";
            this.columnHeader5.Width = 140;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Assessed Value";
            this.columnHeader6.Width = 158;
            // 
            // txt_lot
            // 
            this.txt_lot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lot.Location = new System.Drawing.Point(204, 73);
            this.txt_lot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_lot.Name = "txt_lot";
            this.txt_lot.Size = new System.Drawing.Size(231, 24);
            this.txt_lot.TabIndex = 1;
            // 
            // txt_owner
            // 
            this.txt_owner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_owner.Location = new System.Drawing.Point(204, 110);
            this.txt_owner.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_owner.Name = "txt_owner";
            this.txt_owner.ReadOnly = true;
            this.txt_owner.Size = new System.Drawing.Size(231, 24);
            this.txt_owner.TabIndex = 1;
            // 
            // txt_year
            // 
            this.txt_year.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_year.Location = new System.Drawing.Point(204, 145);
            this.txt_year.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_year.Name = "txt_year";
            this.txt_year.Size = new System.Drawing.Size(231, 24);
            this.txt_year.TabIndex = 1;
            // 
            // txt_market
            // 
            this.txt_market.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_market.Location = new System.Drawing.Point(204, 217);
            this.txt_market.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_market.Name = "txt_market";
            this.txt_market.ReadOnly = true;
            this.txt_market.Size = new System.Drawing.Size(231, 24);
            this.txt_market.TabIndex = 1;
            // 
            // txt_assessed
            // 
            this.txt_assessed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_assessed.Location = new System.Drawing.Point(204, 254);
            this.txt_assessed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_assessed.Name = "txt_assessed";
            this.txt_assessed.ReadOnly = true;
            this.txt_assessed.Size = new System.Drawing.Size(231, 24);
            this.txt_assessed.TabIndex = 1;
            // 
            // txt_lastYear
            // 
            this.txt_lastYear.Location = new System.Drawing.Point(652, 36);
            this.txt_lastYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_lastYear.Name = "txt_lastYear";
            this.txt_lastYear.Size = new System.Drawing.Size(239, 22);
            this.txt_lastYear.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(100, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lot Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(109, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Lot Owner";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(95, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Current Year";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(128, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "Quarter";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(92, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 18);
            this.label5.TabIndex = 2;
            this.label5.Text = "Market Value";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(73, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 18);
            this.label6.TabIndex = 2;
            this.label6.Text = "Assessed Value";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(242)))), ((int)(((byte)(236)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(437, 74);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 25);
            this.button1.TabIndex = 157;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(539, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 18);
            this.label7.TabIndex = 159;
            this.label7.Text = "Last Payment";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.lbl_Total);
            this.groupBox1.Controls.Add(this.lbl_Penalty);
            this.groupBox1.Controls.Add(this.lbl_TaxDue);
            this.groupBox1.Controls.Add(this.lbl_DisTotals);
            this.groupBox1.Controls.Add(this.lblTotal1);
            this.groupBox1.Controls.Add(this.lblTotalDisc);
            this.groupBox1.Controls.Add(this.lblPenalty1);
            this.groupBox1.Controls.Add(this.lblTaxDue1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(531, 76);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(359, 156);
            this.groupBox1.TabIndex = 160;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Totals";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Total.Location = new System.Drawing.Point(120, 128);
            this.lbl_Total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(19, 21);
            this.lbl_Total.TabIndex = 162;
            this.lbl_Total.Text = "0";
            // 
            // lbl_Penalty
            // 
            this.lbl_Penalty.AutoSize = true;
            this.lbl_Penalty.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Penalty.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Penalty.Location = new System.Drawing.Point(120, 66);
            this.lbl_Penalty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Penalty.Name = "lbl_Penalty";
            this.lbl_Penalty.Size = new System.Drawing.Size(19, 21);
            this.lbl_Penalty.TabIndex = 161;
            this.lbl_Penalty.Text = "0";
            // 
            // lbl_TaxDue
            // 
            this.lbl_TaxDue.AutoSize = true;
            this.lbl_TaxDue.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TaxDue.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_TaxDue.Location = new System.Drawing.Point(120, 36);
            this.lbl_TaxDue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TaxDue.Name = "lbl_TaxDue";
            this.lbl_TaxDue.Size = new System.Drawing.Size(19, 21);
            this.lbl_TaxDue.TabIndex = 160;
            this.lbl_TaxDue.Text = "0";
            // 
            // lbl_DisTotals
            // 
            this.lbl_DisTotals.AutoSize = true;
            this.lbl_DisTotals.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DisTotals.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_DisTotals.Location = new System.Drawing.Point(120, 97);
            this.lbl_DisTotals.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DisTotals.Name = "lbl_DisTotals";
            this.lbl_DisTotals.Size = new System.Drawing.Size(19, 21);
            this.lbl_DisTotals.TabIndex = 159;
            this.lbl_DisTotals.Text = "0";
            // 
            // lblTotal1
            // 
            this.lblTotal1.AutoSize = true;
            this.lblTotal1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotal1.Location = new System.Drawing.Point(21, 128);
            this.lblTotal1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotal1.Name = "lblTotal1";
            this.lblTotal1.Size = new System.Drawing.Size(56, 21);
            this.lblTotal1.TabIndex = 150;
            this.lblTotal1.Text = "Total:";
            this.lblTotal1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTotalDisc
            // 
            this.lblTotalDisc.AutoSize = true;
            this.lblTotalDisc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalDisc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalDisc.Location = new System.Drawing.Point(21, 97);
            this.lblTotalDisc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalDisc.Name = "lblTotalDisc";
            this.lblTotalDisc.Size = new System.Drawing.Size(87, 21);
            this.lblTotalDisc.TabIndex = 149;
            this.lblTotalDisc.Text = "Discount:";
            this.lblTotalDisc.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblPenalty1
            // 
            this.lblPenalty1.AutoSize = true;
            this.lblPenalty1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPenalty1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPenalty1.Location = new System.Drawing.Point(21, 66);
            this.lblPenalty1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPenalty1.Name = "lblPenalty1";
            this.lblPenalty1.Size = new System.Drawing.Size(76, 21);
            this.lblPenalty1.TabIndex = 148;
            this.lblPenalty1.Text = "Penalty:";
            this.lblPenalty1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTaxDue1
            // 
            this.lblTaxDue1.AutoSize = true;
            this.lblTaxDue1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTaxDue1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTaxDue1.Location = new System.Drawing.Point(21, 36);
            this.lblTaxDue1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTaxDue1.Name = "lblTaxDue1";
            this.lblTaxDue1.Size = new System.Drawing.Size(82, 21);
            this.lblTaxDue1.TabIndex = 147;
            this.lblTaxDue1.Text = "Tax Due:";
            this.lblTaxDue1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cmb_quarter
            // 
            this.cmb_quarter.FormattingEnabled = true;
            this.cmb_quarter.Items.AddRange(new object[] {
            "First Quarter",
            "Second Quarter",
            "Third Quarter",
            "Fourth Quater"});
            this.cmb_quarter.Location = new System.Drawing.Point(204, 181);
            this.cmb_quarter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_quarter.Name = "cmb_quarter";
            this.cmb_quarter.Size = new System.Drawing.Size(231, 24);
            this.cmb_quarter.TabIndex = 161;
            // 
            // btn_compute
            // 
            this.btn_compute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_compute.Location = new System.Drawing.Point(531, 239);
            this.btn_compute.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_compute.Name = "btn_compute";
            this.btn_compute.Size = new System.Drawing.Size(139, 57);
            this.btn_compute.TabIndex = 162;
            this.btn_compute.Text = "Compute";
            this.btn_compute.UseVisualStyleBackColor = false;
            this.btn_compute.Click += new System.EventHandler(this.btn_compute_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_Next.Location = new System.Drawing.Point(751, 239);
            this.btn_Next.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(139, 57);
            this.btn_Next.TabIndex = 162;
            this.btn_Next.Text = "Next Client";
            this.btn_Next.UseVisualStyleBackColor = false;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_Back.Location = new System.Drawing.Point(12, 12);
            this.btn_Back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(83, 28);
            this.btn_Back.TabIndex = 163;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // lbl_id
            // 
            this.lbl_id.AutoSize = true;
            this.lbl_id.Location = new System.Drawing.Point(441, 117);
            this.lbl_id.Name = "lbl_id";
            this.lbl_id.Size = new System.Drawing.Size(46, 17);
            this.lbl_id.TabIndex = 164;
            this.lbl_id.Text = "label8";
            this.lbl_id.Visible = false;
            // 
            // lbl_tax
            // 
            this.lbl_tax.AutoSize = true;
            this.lbl_tax.Location = new System.Drawing.Point(919, 86);
            this.lbl_tax.Name = "lbl_tax";
            this.lbl_tax.Size = new System.Drawing.Size(46, 17);
            this.lbl_tax.TabIndex = 165;
            this.lbl_tax.Text = "label8";
            this.lbl_tax.Visible = false;
            // 
            // lbl_pen
            // 
            this.lbl_pen.AutoSize = true;
            this.lbl_pen.Location = new System.Drawing.Point(919, 117);
            this.lbl_pen.Name = "lbl_pen";
            this.lbl_pen.Size = new System.Drawing.Size(46, 17);
            this.lbl_pen.TabIndex = 165;
            this.lbl_pen.Text = "label8";
            this.lbl_pen.Visible = false;
            // 
            // frm_Compute_Tax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1008, 698);
            this.Controls.Add(this.lbl_pen);
            this.Controls.Add(this.lbl_tax);
            this.Controls.Add(this.lbl_id);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_compute);
            this.Controls.Add(this.cmb_quarter);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_assessed);
            this.Controls.Add(this.txt_market);
            this.Controls.Add(this.txt_year);
            this.Controls.Add(this.txt_owner);
            this.Controls.Add(this.txt_lastYear);
            this.Controls.Add(this.txt_lot);
            this.Controls.Add(this.lvi_records);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frm_Compute_Tax";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Compute Tax";
            this.Load += new System.EventHandler(this.frm_Compute_Tax_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvi_records;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.TextBox txt_lot;
        private System.Windows.Forms.TextBox txt_owner;
        private System.Windows.Forms.TextBox txt_year;
        private System.Windows.Forms.TextBox txt_market;
        private System.Windows.Forms.TextBox txt_assessed;
        private System.Windows.Forms.TextBox txt_lastYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_Penalty;
        private System.Windows.Forms.Label lbl_TaxDue;
        private System.Windows.Forms.Label lbl_DisTotals;
        private System.Windows.Forms.Label lblTotal1;
        private System.Windows.Forms.Label lblTotalDisc;
        private System.Windows.Forms.Label lblPenalty1;
        private System.Windows.Forms.Label lblTaxDue1;
        private System.Windows.Forms.ComboBox cmb_quarter;
        private System.Windows.Forms.Button btn_compute;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label lbl_id;
        private System.Windows.Forms.Label lbl_tax;
        private System.Windows.Forms.Label lbl_pen;

    }
}