﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_admin_surveyor : Form
    {
        public frm_admin_surveyor()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Assessor asse = new frm_Assessor();
            asse.Show();
            this.Hide();
        }        
    }
}
