﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class Form1 : Form
    {
        dbConn con = new dbConn();

        public Form1()
        {
            InitializeComponent();
        }
        
        private void btn_Save_Click(object sender, EventArgs e)
        {
            string user = txt_username.Text.Trim().ToString();
            string pass = con.encryption(txt_password.Text.Trim().ToString());
            //string user_type = lbl_user_type.Text.Trim().ToString();

            string sqlSelect = "SELECT `Username`, `Password` FROM `tbl_admin` WHERE `Username` = '"+user+"'";
            con.Select(sqlSelect, lbl_user, lbl_pass);

            string sqlSelect1 = "SELECT `Username`, `Password` FROM `tbl_users` WHERE `Username` = '" + user + "'";
            con.Select(sqlSelect1, lbl_user1, lbl_pass1);

            //string sqlSelect2 = "SELECT `Username`, `Password` FROM `tbl_admin` WHERE `Username` = '" + user + "'";
            //con.Select(sqlSelect2, lbl_user2, lbl_pass2);


            if (user == "" || pass == "")
                {
                    MessageBox.Show("Enter user.");
                }
            else if (user == "assessor" && pass == lbl_pass.Text)
                {
                    frm_Assessor lot = new frm_Assessor();
                    lot.Show();
                    this.Hide();
                }
            else if (user == "treasurer" && pass == lbl_pass.Text)
                {
                    frm_Treasury cash = new frm_Treasury();
                    cash.Show();
                    this.Hide();
                }
            else if (user == lbl_user1.Text && pass == lbl_pass1.Text)
                    {
                        frm_users users = new frm_users();
                        users.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid.");
                    }
                    
                }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         frm_Register c8 = new frm_Register();
            c8.Show();
            this.Hide();
        }
       
            
        }

        
    
}
