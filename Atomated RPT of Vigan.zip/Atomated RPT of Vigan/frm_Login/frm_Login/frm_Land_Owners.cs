﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Land_Owners : Form
    {
        dbConn con = new dbConn();

        public frm_Land_Owners()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Assessor asse = new frm_Assessor();
            asse.Show();
            this.Hide();
        }

        private void frm_Land_Owners_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT * FROM `tbl_land_owner` LEFT JOIN `tbl_land_info` ON `tbl_land_info`.`Owner_FK` = `tbl_land_owner`.`ID`";
            con.view(sqlSelect, lvi_owners);
        }
    }
}
