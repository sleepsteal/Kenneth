﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_landrecord : Form
    {
        dbConn con = new dbConn();

        public frm_landrecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_Add_Record add = new frm_Add_Record();
            add.Show();
            this.Hide();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Assessor asse = new frm_Assessor();
            asse.Show();
            this.Hide();
        }

        private void frm_landrecord_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT * FROM `tbl_land_info`";
            con.getLot(sqlSelect, lvi_Lot);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string lot = txt_search.Text.Trim().ToString();

            string sqlDelete = "DELETE FROM `tbl_land_info` WHERE `Lot_Number` = '"+lot+"'";
            con.delete(sqlDelete);
            MessageBox.Show("Successfully deleted.");
        }        
    }
}
