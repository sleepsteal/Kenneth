﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_users : Form
    {
        public frm_users()
        {
            InitializeComponent();
        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Logout?", "Logout?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Form1 login = new Form1();
                login.Show();
                this.Hide();
            }
            else
            {
                //do nothing
            }
        }

        private void btn_viewRecords_Click(object sender, EventArgs e)
        {
            frm_Land_Records lnd = new frm_Land_Records();
            lnd.Show();
            this.Hide();
        }

        private void btn_requestSurveyor_Click(object sender, EventArgs e)
        {
            frm_Request_Surveyor suv = new frm_Request_Surveyor();
            suv.Show();
            this.Hide();
        }

        private void btn_requestAssessment_Click(object sender, EventArgs e)
        {
            frm_Request_Assessment assess = new frm_Request_Assessment();
            assess.Show();
            this.Hide();
        }
    }
}
