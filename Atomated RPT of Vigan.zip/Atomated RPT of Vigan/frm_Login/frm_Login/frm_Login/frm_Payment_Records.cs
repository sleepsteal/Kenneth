﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Payment_Records : Form
    {
        dbConn con = new dbConn();

        public frm_Payment_Records()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Treasury tres = new frm_Treasury();
            tres.Show();
            this.Hide();
        }

        private void frm_Payment_Records_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT * FROM `tbl_t_records`";
            con.getRecord(sqlSelect, lvi_records);
        }
    }
}
