﻿namespace frm_Login
{
    partial class frm_Assessor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Assessor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_survey = new System.Windows.Forms.Button();
            this.btn_assessment = new System.Windows.Forms.Button();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.btn_map = new System.Windows.Forms.Button();
            this.btn_owners = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_records = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btn_survey);
            this.panel1.Controls.Add(this.btn_assessment);
            this.panel1.Controls.Add(this.btn_logOut);
            this.panel1.Controls.Add(this.btn_map);
            this.panel1.Controls.Add(this.btn_owners);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btn_records);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 609);
            this.panel1.TabIndex = 0;
            // 
            // btn_survey
            // 
            this.btn_survey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_survey.Location = new System.Drawing.Point(16, 375);
            this.btn_survey.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_survey.Name = "btn_survey";
            this.btn_survey.Size = new System.Drawing.Size(112, 48);
            this.btn_survey.TabIndex = 10;
            this.btn_survey.Text = "Surveyor Request";
            this.btn_survey.UseVisualStyleBackColor = false;
            this.btn_survey.Click += new System.EventHandler(this.btn_survey_Click);
            // 
            // btn_assessment
            // 
            this.btn_assessment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_assessment.Location = new System.Drawing.Point(16, 322);
            this.btn_assessment.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_assessment.Name = "btn_assessment";
            this.btn_assessment.Size = new System.Drawing.Size(112, 48);
            this.btn_assessment.TabIndex = 9;
            this.btn_assessment.Text = "Assessment Request";
            this.btn_assessment.UseVisualStyleBackColor = false;
            this.btn_assessment.Click += new System.EventHandler(this.btn_assessment_Click);
            // 
            // btn_logOut
            // 
            this.btn_logOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_logOut.Location = new System.Drawing.Point(16, 535);
            this.btn_logOut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(112, 48);
            this.btn_logOut.TabIndex = 8;
            this.btn_logOut.Text = "Logout";
            this.btn_logOut.UseVisualStyleBackColor = false;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // btn_map
            // 
            this.btn_map.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_map.Location = new System.Drawing.Point(16, 269);
            this.btn_map.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_map.Name = "btn_map";
            this.btn_map.Size = new System.Drawing.Size(112, 48);
            this.btn_map.TabIndex = 7;
            this.btn_map.Text = "Cadastral Map";
            this.btn_map.UseVisualStyleBackColor = false;
            this.btn_map.Click += new System.EventHandler(this.btn_map_Click);
            // 
            // btn_owners
            // 
            this.btn_owners.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_owners.Location = new System.Drawing.Point(16, 217);
            this.btn_owners.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_owners.Name = "btn_owners";
            this.btn_owners.Size = new System.Drawing.Size(112, 47);
            this.btn_owners.TabIndex = 5;
            this.btn_owners.Text = "Land Owners";
            this.btn_owners.UseVisualStyleBackColor = false;
            this.btn_owners.Click += new System.EventHandler(this.btn_owners_Click);
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(16, 15);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(122, 131);
            this.panel3.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 41);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Image";
            // 
            // btn_records
            // 
            this.btn_records.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_records.Location = new System.Drawing.Point(16, 171);
            this.btn_records.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_records.Name = "btn_records";
            this.btn_records.Size = new System.Drawing.Size(112, 41);
            this.btn_records.TabIndex = 0;
            this.btn_records.Text = "Land Records";
            this.btn_records.UseVisualStyleBackColor = false;
            this.btn_records.Click += new System.EventHandler(this.btn_records_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(150, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(596, 71);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(271, 214);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 36);
            this.label1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Location = new System.Drawing.Point(150, 70);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(596, 539);
            this.panel4.TabIndex = 3;
            // 
            // frm_Assessor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 609);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frm_Assessor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Assessor";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Button btn_map;
        private System.Windows.Forms.Button btn_owners;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_records;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_assessment;
        private System.Windows.Forms.Button btn_survey;
        private System.Windows.Forms.Panel panel4;
    }
}