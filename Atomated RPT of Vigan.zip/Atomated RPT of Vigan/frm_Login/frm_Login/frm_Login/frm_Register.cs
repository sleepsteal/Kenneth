﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Register : Form
    {
        dbConn con = new dbConn();

        public frm_Register()
        {
            InitializeComponent();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            string fname = txt_fname.Text.Trim().ToString();
            string mname = txt_mname.Text.Trim().ToString();
            string lname = txt_lname.Text.Trim().ToString();
            string brgy = txt_brgy.Text.Trim().ToString();
            string city = txt_city.Text.Trim().ToString();
            string prov = txt_prov.Text.Trim().ToString();
            string contact = txt_cell.Text.Trim().ToString();
            string user = txt_user.Text.Trim().ToString();
            string pass = con.encryption(txt_pass.Text.Trim().ToString());

            string sqlInsert = "INSERT INTO `tbl_user_data`(`First_Name`, `Middle_Name`, `Last_Name`, `Barangay`, `City/Mun`, `Province`, `Contact`) VALUES ('" + fname + "', '" + mname + "', '" + lname + "', '" + brgy + "', '" + city + "', '" + prov + "', '" + contact + "')";
            con.insert(sqlInsert);

            string sqlSelect = "SELECT `ID` FROM `tbl_user_data` where `First_Name`='" + fname + "' AND `Last_Name` = '" + lname + "'";
            txt_fname.Text = sqlSelect;
            con.Select_ID(sqlSelect, lbl_ID);            

            string id = lbl_ID.Text.Trim().ToString();
            string sqlInsert_1 = "INSERT INTO `tbl_users` (`User_FK`, `Username`, `Password`, `User_Type`) VALUES('" + id + "', '" + user + "', '" + pass + "', 'U')";
            con.insert(sqlInsert_1);

            MessageBox.Show("Resgistration Complete");
        }               
    }
}
