﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_SetTax : Form
    {
        dbConn con = new dbConn();
        public frm_SetTax()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_Treasury tres = new frm_Treasury();
            tres.Show();
            this.Hide();
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            string tax = txt_tax.Text.Trim().ToString();
            string pen = txt_pen.Text.Trim().ToString();
            string sqlInsert = "INSERT INTO `tbl_tax` (`Tax`, `Penalty`) VALUES ('"+tax+"', '"+pen+"')";
            con.insert(sqlInsert);
            MessageBox.Show("Saved");

            
        }

        private void frm_SetTax_Load(object sender, EventArgs e)
        {
            string sqlSelect = "SELECT `Tax`, `Penalty` FROM `tbl_tax`";
            con.getTax(sqlSelect, lbl_tax, lbl_pen);
        }
    }
}
