﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Request_Surveyor : Form
    {
        public frm_Request_Surveyor()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_users user = new frm_users();
            user.Show();
            this.Hide();
        }      
                
    }
}
