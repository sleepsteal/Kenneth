﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Request_Assessment : Form
    {
        dbConn con = new dbConn();
        public frm_Request_Assessment()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            frm_users user = new frm_users();
            user.Show();
            this.Hide();
        }

        private void btn_request_Click(object sender, EventArgs e)
        {
            string name = txt_fullname.Text.Trim().ToString();
            string brgy = txt_brgy.Text.Trim().ToString();
            string city = txt_mun.Text.Trim().ToString();
            string prov = txt_prov.Text.Trim().ToString();
            string cell = mkd_cell.Text.Trim().ToString();
            string type = cmb_type.Text.Trim().ToString();
            string loc = txt_location.Text.Trim().ToString();

            string sqlInsert = "INSERT INTO `tbl_assessment_request`(`Full_Name`, `Barangay`, `City/Mun`, `Province`, `Cell_Number`, `Type`, `Location`) VALUES ('"+name+"', '"+brgy+"', '"+city+"', '"+prov+"', '"+cell+"', '"+type+"', '"+loc+"')";
            con.insert(sqlInsert);
            MessageBox.Show("Saved");
        }       
    }
}
