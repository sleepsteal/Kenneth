﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Treasury : Form
    {
        public frm_Treasury()
        {
            InitializeComponent();
        }

        private void btn_set_Tax_Click(object sender, EventArgs e)
        {
            frm_SetTax set = new frm_SetTax();
            set.Show();
            this.Hide();
        }

        private void btn_payment_records_Click(object sender, EventArgs e)
        {
            frm_Payment_Records pay = new frm_Payment_Records();
            pay.Show();
            this.Hide();
        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Logout?", "Logout?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Form1 login = new Form1();
                login.Show();
                this.Hide();
            }
            else
            {
                //do nothing
            }
        }

        private void btn_compute_Click(object sender, EventArgs e)
        {
            frm_Compute_Tax tax = new frm_Compute_Tax();
            tax.Show();
            this.Hide();
        }
    }
}
