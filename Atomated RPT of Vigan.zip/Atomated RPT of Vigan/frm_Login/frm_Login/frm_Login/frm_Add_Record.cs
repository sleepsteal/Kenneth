﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace frm_Login
{
    public partial class frm_Add_Record : Form
    {
        dbConn con = new dbConn();
        public frm_Add_Record()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            string name = txt_fullname.Text.Trim().ToString();
            string brgy = txt_brgy.Text.Trim().ToString();
            string city = txt_mun.Text.Trim().ToString();
            string prov = txt_prov.Text.Trim().ToString();
            string num = txt_contact.Text.Trim().ToString();
           

            string lot_num = txt_lot.Text.Trim().ToString();
            string loc = txt_loc.Text.Trim().ToString();
            string classification = cmb_class.Text.Trim().ToString();
            string use = cmb_actual.Text.Trim().ToString();
            string area = txt_land.Text.Trim().ToString();
            string market = txt_market.Text.Trim().ToString();
            string assess = txt_assessed.Text.Trim().ToString();
            string tax = txt_decla.Text.Trim().ToString();
            string status = cmb_status.Text.Trim().ToString();

            if (cb_Et.Checked == true)
            {
                name = name + " (et. al)";
            }
            else
            {
                name = txt_fullname.Text;
            }
            if (name == "" || brgy == "" || city == "" || prov == "" || num == "" || lot_num == "" || loc == "" || classification == "" || use == "" || area == "" || market == "" || assess == "" || tax == "" || status == "")
            {
                MessageBox.Show("Kulang");
            }
            else
            {
                string sqlInsert = "INSERT INTO `tbl_land_owner` (`Full_Name`, `Barangay`, `City/Mun`, `Province`, `Contact`) VALUES ('" + name + "', '" + brgy + "', '" + city + "', '" + prov + "', '" + num + "')";
                con.insert(sqlInsert);

                string sqlSelect = "SELECT `ID` FROM `tbl_land_owner` WHERE `Full_Name` = '" + name + "'";
                con.search(sqlSelect, lbl_OwnerID);

                string id = lbl_OwnerID.Text.Trim().ToString();
                string sqlInsert1 = "INSERT INTO `tbl_land_info` (`Owner_FK`, `Lot_Number`, `Lot_Location`, `Classification`, `Actual_Use`, `Land_Area`, `Market_Value`, `Assessed_Value`, `Tax_Dec_Number`, `Status`) VALUES ('" + id + "', '" + lot_num + "', '" + loc + "', '" + classification + "', '" + use + "', '" + area + "', '" + market + "', '" + assess + "', '" + tax + "', '" + status + "')";
                con.insert(sqlInsert1);

                MessageBox.Show("Saved");
            }
            
        }           
    }
}
