﻿namespace frm_Login
{
    partial class frm_Request_Assessment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Request_Assessment));
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_mun = new System.Windows.Forms.TextBox();
            this.txt_prov = new System.Windows.Forms.TextBox();
            this.txt_brgy = new System.Windows.Forms.TextBox();
            this.txt_fullname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmb_type = new System.Windows.Forms.ComboBox();
            this.txt_location = new System.Windows.Forms.TextBox();
            this.mkd_cell = new System.Windows.Forms.MaskedTextBox();
            this.btn_request = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(20, 218);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Cellphone Num";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(50, 185);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Province";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(46, 118);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Barangay";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(45, 152);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "City / Mun";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(44, 85);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Full Name";
            // 
            // txt_mun
            // 
            this.txt_mun.Location = new System.Drawing.Point(114, 148);
            this.txt_mun.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_mun.Name = "txt_mun";
            this.txt_mun.Size = new System.Drawing.Size(262, 20);
            this.txt_mun.TabIndex = 8;
            // 
            // txt_prov
            // 
            this.txt_prov.Location = new System.Drawing.Point(113, 183);
            this.txt_prov.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_prov.Name = "txt_prov";
            this.txt_prov.Size = new System.Drawing.Size(262, 20);
            this.txt_prov.TabIndex = 6;
            // 
            // txt_brgy
            // 
            this.txt_brgy.Location = new System.Drawing.Point(114, 113);
            this.txt_brgy.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_brgy.Name = "txt_brgy";
            this.txt_brgy.Size = new System.Drawing.Size(262, 20);
            this.txt_brgy.TabIndex = 4;
            // 
            // txt_fullname
            // 
            this.txt_fullname.Location = new System.Drawing.Point(114, 78);
            this.txt_fullname.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_fullname.Name = "txt_fullname";
            this.txt_fullname.Size = new System.Drawing.Size(262, 20);
            this.txt_fullname.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(12, 252);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Type of Property";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(51, 285);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Location";
            // 
            // cmb_type
            // 
            this.cmb_type.FormattingEnabled = true;
            this.cmb_type.Items.AddRange(new object[] {
            "Land",
            "House"});
            this.cmb_type.Location = new System.Drawing.Point(113, 247);
            this.cmb_type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmb_type.Name = "cmb_type";
            this.cmb_type.Size = new System.Drawing.Size(186, 21);
            this.cmb_type.TabIndex = 12;
            // 
            // txt_location
            // 
            this.txt_location.Location = new System.Drawing.Point(113, 282);
            this.txt_location.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_location.Name = "txt_location";
            this.txt_location.Size = new System.Drawing.Size(186, 20);
            this.txt_location.TabIndex = 7;
            // 
            // mkd_cell
            // 
            this.mkd_cell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mkd_cell.Location = new System.Drawing.Point(113, 212);
            this.mkd_cell.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mkd_cell.Mask = "(+63)000-000-0000";
            this.mkd_cell.Name = "mkd_cell";
            this.mkd_cell.Size = new System.Drawing.Size(186, 21);
            this.mkd_cell.TabIndex = 13;
            // 
            // btn_request
            // 
            this.btn_request.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_request.Location = new System.Drawing.Point(113, 10);
            this.btn_request.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_request.Name = "btn_request";
            this.btn_request.Size = new System.Drawing.Size(115, 37);
            this.btn_request.TabIndex = 14;
            this.btn_request.Text = "Request";
            this.btn_request.UseVisualStyleBackColor = false;
            this.btn_request.Click += new System.EventHandler(this.btn_request_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.btn_Back.Location = new System.Drawing.Point(308, 18);
            this.btn_Back.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(67, 24);
            this.btn_Back.TabIndex = 185;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(405, 51);
            this.panel1.TabIndex = 186;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(73)))));
            this.panel2.Controls.Add(this.btn_request);
            this.panel2.Controls.Add(this.btn_Back);
            this.panel2.Location = new System.Drawing.Point(0, 320);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(405, 56);
            this.panel2.TabIndex = 187;
            // 
            // frm_Request_Assessment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(403, 375);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mkd_cell);
            this.Controls.Add(this.cmb_type);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_fullname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_brgy);
            this.Controls.Add(this.txt_prov);
            this.Controls.Add(this.txt_location);
            this.Controls.Add(this.txt_mun);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frm_Request_Assessment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Request Assessment";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_mun;
        private System.Windows.Forms.TextBox txt_prov;
        private System.Windows.Forms.TextBox txt_brgy;
        private System.Windows.Forms.TextBox txt_fullname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_type;
        private System.Windows.Forms.TextBox txt_location;
        private System.Windows.Forms.MaskedTextBox mkd_cell;
        private System.Windows.Forms.Button btn_request;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}