-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2019 at 05:25 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_prototype`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `User_Type` varchar(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`ID`, `Username`, `Password`, `User_Type`) VALUES
(1, 'assessor', '827ccb0eea8a706c4c34a16891f84e7b', 'A'),
(2, 'treasurer', '827ccb0eea8a706c4c34a16891f84e7b', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assessment_request`
--

CREATE TABLE IF NOT EXISTS `tbl_assessment_request` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Full_Name` varchar(50) NOT NULL,
  `Barangay` varchar(50) NOT NULL,
  `City/Mun` varchar(50) NOT NULL,
  `Province` text NOT NULL,
  `Cell_Number` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_assessment_request`
--

INSERT INTO `tbl_assessment_request` (`ID`, `Full_Name`, `Barangay`, `City/Mun`, `Province`, `Cell_Number`, `Type`, `Location`) VALUES
(1, 'qwerty', 'qw', 'er', 'ty', '(+63)955-555-5555', 'House', 'Poblacion, Sta. Catalina');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_land_info`
--

CREATE TABLE IF NOT EXISTS `tbl_land_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Owner_FK` int(20) NOT NULL,
  `Lot_Number` varchar(50) NOT NULL,
  `Lot_Location` varchar(50) NOT NULL,
  `Classification` varchar(50) NOT NULL,
  `Actual_Use` varchar(50) NOT NULL,
  `Land_Area` varchar(50) NOT NULL,
  `Market_Value` varchar(50) NOT NULL,
  `Assessed_Value` varchar(50) NOT NULL,
  `Tax_Dec_Number` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `Owner_FK` (`Owner_FK`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_land_info`
--

INSERT INTO `tbl_land_info` (`ID`, `Owner_FK`, `Lot_Number`, `Lot_Location`, `Classification`, `Actual_Use`, `Land_Area`, `Market_Value`, `Assessed_Value`, `Tax_Dec_Number`, `Status`) VALUES
(1, 1, '1', 's', 'Commercial', 'Commerial Land', '1111', '444', '555', '11', 'Titled'),
(2, 2, '2', 'e', 'Commercial', 'Commerial Land', '1111', '444', '333', '12', 'Untitled'),
(3, 3, '1-B', 'Sta. Catalina', 'Residential', 'Residential Lot', '10000', '5000', '5000', '10012', 'Titled');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_land_owner`
--

CREATE TABLE IF NOT EXISTS `tbl_land_owner` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Full_Name` varchar(200) NOT NULL,
  `Barangay` varchar(20) NOT NULL,
  `City/Mun` varchar(20) NOT NULL,
  `Province` varchar(20) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_land_owner`
--

INSERT INTO `tbl_land_owner` (`ID`, `Full_Name`, `Barangay`, `City/Mun`, `Province`, `Contact`) VALUES
(1, 'aa', 'a', 'a', 'a', '1'),
(2, 'aaet. al', 'w', 'w', 'w', '2'),
(3, 'Kenneth Javier (et. al)', 'Poblacion', 'Sta. Catalina', 'Ilocos Sur', '0995-1484491');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tax`
--

CREATE TABLE IF NOT EXISTS `tbl_tax` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Tax` varchar(50) NOT NULL,
  `Penalty` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_tax`
--

INSERT INTO `tbl_tax` (`ID`, `Tax`, `Penalty`) VALUES
(1, '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_t_records`
--

CREATE TABLE IF NOT EXISTS `tbl_t_records` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Lot_Number` varchar(11) NOT NULL,
  `Lot_Owner` varchar(50) NOT NULL,
  `Year_Paid` varchar(11) NOT NULL,
  `Market_Value` varchar(50) NOT NULL,
  `Assessed_Value` varchar(50) NOT NULL,
  `Total_Due` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_t_records`
--

INSERT INTO `tbl_t_records` (`ID`, `Lot_Number`, `Lot_Owner`, `Year_Paid`, `Market_Value`, `Assessed_Value`, `Total_Due`) VALUES
(1, '2', 'aaet. al', '2019', '444', '333', '? 33.99'),
(2, '1', 'aa', '2019', '444', '555', '? 23.82'),
(3, '1-b', 'Kenneth Javier (et. al)', '2019', '5000', '5000', '? 218.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_FK` int(50) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `User_Type` varchar(5) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `User_FK` (`User_FK`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`ID`, `User_FK`, `Username`, `Password`, `User_Type`) VALUES
(10, 10, '11', '6512bd43d9caa6e02c990b0a82652dca', 'U');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_data`
--

CREATE TABLE IF NOT EXISTS `tbl_user_data` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(50) NOT NULL,
  `Middle_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Barangay` varchar(50) NOT NULL,
  `City/Mun` varchar(50) NOT NULL,
  `Province` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_user_data`
--

INSERT INTO `tbl_user_data` (`ID`, `First_Name`, `Middle_Name`, `Last_Name`, `Barangay`, `City/Mun`, `Province`, `Contact`) VALUES
(1, 'Q', 'W', 'E', 'Y', 'T', 'R', '1'),
(2, 'a', '', 'a', 'a', 'a', 'a', '1111111111111111'),
(3, 'a', '', 'a', 'a', 'a', 'a', 'a'),
(4, 'b', 'b', 'b', 'b', 'b', 'b', 'b'),
(5, 'c', 'c', 'c', 'c', 'c', 'c', 'c'),
(6, 'k', 'k', 'k', 'k', 'k', 'k', 'k'),
(7, 'w', 'w', 'w', 'w', 'w', 'w', 'w'),
(8, 'd', 'd', 'd', 'd', 'dd', 'd', 'dd'),
(9, 'x', 'x', 'x', 'x', 'x', 'x', 'x'),
(10, 'qw', 'qw', 'qw', 'qw', 'qw', 'qw', 'qw');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_land_info`
--
ALTER TABLE `tbl_land_info`
  ADD CONSTRAINT `tbl_land_info_ibfk_1` FOREIGN KEY (`Owner_FK`) REFERENCES `tbl_land_owner` (`ID`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD CONSTRAINT `tbl_users_ibfk_1` FOREIGN KEY (`User_FK`) REFERENCES `tbl_user_data` (`ID`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
